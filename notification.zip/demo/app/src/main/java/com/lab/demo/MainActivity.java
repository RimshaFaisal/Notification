package com.lab.demo;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.NotificationCompat;
import androidx.core.app.NotificationManagerCompat;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;
import javax.xml.namespace.QName;

public class MainActivity extends AppCompatActivity {
    private static final String CHANNEL_ID = "channel_id1";
    private static final int NOTIFICATION_ID = 1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        final Button showNotificationBtn = findViewById(R.id.nf);

        showNotificationBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                // to show notification
                showNotification();
            }
        });
    }
    private void showNotification() {
        createNotificationChannel();

        // creating notification
        NotificationCompat.Builder bld=new NotificationCompat.Builder(this,CHANNEL_ID);
        //for icon
        bld.setSmallIcon(R.drawable.not);
        //setting title
        bld.setContentTitle("You have a Notification!");
        //description
        bld.setContentText("Notification perform by Rimsha Faisal");
        //priority
        bld.setPriority(NotificationCompat.PRIORITY_DEFAULT);
        //notification manager
        NotificationManagerCompat notmc = NotificationManagerCompat.from(this);
        notmc.notify(NOTIFICATION_ID, bld.build());
    }
    private void createNotificationChannel() {
        if(Build.VERSION.SDK_INT>=Build.VERSION_CODES.O)
        {
            CharSequence nm="My Notification";
            String des = "Description";
            int imp=NotificationManager.IMPORTANCE_DEFAULT;
            NotificationChannel notch = new NotificationChannel(CHANNEL_ID,nm,imp);
            notch.setDescription(des);

            NotificationManager notm=(NotificationManager)getSystemService(NOTIFICATION_SERVICE);
            notm.createNotificationChannel(notch);        }
    }
}
class NotificationReceiver extends BroadcastReceiver{
    private String name;
    @Override
    public void onReceive(Context context, Intent intent)
    {
        String msg=intent.getStringExtra(name="Message");
        Toast.makeText(context,msg,Toast.LENGTH_SHORT).show();
    }
}






